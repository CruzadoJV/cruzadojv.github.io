import turtle
from Part import function
from Part import difficult

alex = turtle.Turtle()
alec = turtle.Turtle()
levi = turtle.Turtle()
lev = turtle.Turtle()

function(alex, 100)
function(alec, 150)
function(levi, 200)
function(lev, 250)


dev = turtle.Turtle()
ved = turtle.Turtle()
eev = turtle.Turtle()


difficult(dev, 100)
difficult(ved, 150)
difficult(eev, 200)



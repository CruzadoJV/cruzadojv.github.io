import turtle
def draw_square(t,size):
    for i in range(4):
        t.forward(size)
        t.left(90)
steve = turtle.Screen()
dan = turtle.Turtle()
sizevar = 1
for i in range(10):
    draw_square(dan, sizevar)
    sizevar += 20
    dan.penup()
    dan.goto(5,5)
    dan.backward(15)
    dan.right(90)
    dan.forward(15)
    dan.left(90)
    dan.pendown()

import turtle
def draw_square(t, size):
   for i in range(4):
       t.forward(size)
       t.left(90)
wn = turtle.Screen()
dan = turtle.Turtle()
sizevar = 1
for i in range(10):
   draw_square(dan, sizevar)
   sizevar += 20
   dan.penup()
   dan.backward(10)
   dan.right(90)
   dan.forward(10)
   dan.left(90)
   dan.pendown()

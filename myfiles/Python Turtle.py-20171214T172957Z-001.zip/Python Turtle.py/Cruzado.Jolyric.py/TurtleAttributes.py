import turtle
from random import randint

difficult = turtle.Turtle()
difficult.shape('turtle')
#6 different shapes inluding classic/original.
j = turtle.Screen()
t = turtle.Screen()
t.colormode(255)
j.bgcolor(255,255,90)
#Color (255,255,255) is white.
#Color (0,255,0) is green.
#Color (0,0,0) is black.
difficult.speed(1)
#Speed 0 is the fastest while 10 is the slowest.
def draw_square ():
    for i in range(0,4):
        re = randint(0,255)
        bl = randint(0,255)
        gr = randint(0,255)
        difficult.color(re,bl,gr)
        difficult.forward(100)
        difficult.stamp()
        difficult.left(90)

draw_square()

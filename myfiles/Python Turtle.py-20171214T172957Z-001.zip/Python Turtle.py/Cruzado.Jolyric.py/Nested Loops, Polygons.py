import turtle
def draw_square(t,size):
    for i in range(5):
        t.forward(size)
        t.left(72)
steve = turtle.Screen()
pan = turtle.Turtle()
sizevar = 1
for i in range(10):
    draw_square(pan, sizevar)
    sizevar += 20
    pan.penup()
    pan.goto(5,5)
    pan.backward(15)
    pan.right(90)
    pan.forward(15)
    pan.left(90)
    pan.pendown()



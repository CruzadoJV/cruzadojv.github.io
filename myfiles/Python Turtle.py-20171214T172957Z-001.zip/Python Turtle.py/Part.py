import turtle



def function(whatever, n):
    for i in range(4):
        whatever.forward(n)
        whatever.left(90)



def difficult(anything, x):
    for i in range(4):
        anything.down(x)
        anything.right(90)

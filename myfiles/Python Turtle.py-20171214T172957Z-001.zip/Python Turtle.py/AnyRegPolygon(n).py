import turtle

window = turtle.Screen()
window.bgcolor("black")

shape = turtle.Turtle()
shape.color("blue")
shape.pensize(2)
y = 35
x = int(input("How many sides do you want?: "))

def difficult(x,y):

    for i in range(x):
        shape.forward(y)
        shape.left(360/x)

difficult(x,y)

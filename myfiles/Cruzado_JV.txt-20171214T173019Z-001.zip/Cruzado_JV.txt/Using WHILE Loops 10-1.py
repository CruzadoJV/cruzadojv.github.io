acc = 10


while acc < 11:
        print (acc)
        acc = acc - 1

import time

print('Welcome, enter a number -->:  ')
acc = int(input())


while acc > 0:
    print (acc)
    time.sleep(1.0)
    acc = acc - 1
print ('Timer complete!')

def difficult():
    acc = 100
    for i in range(acc):
        print(acc)
        acc = acc - 1
difficult()
print ('Yeah! it is done.')

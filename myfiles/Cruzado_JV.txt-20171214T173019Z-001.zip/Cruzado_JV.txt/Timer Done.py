import time 
def JV():
    print ('Hello, choose a number :)')
    x = int(input())
    for i in range (x):
        time.sleep(1.0)
        print (x-i)
    return 0 
print (JV())
print ('Timer is done!')

        

def JV():
 for i in range (11):
       print (10-i)
print (JV())
	

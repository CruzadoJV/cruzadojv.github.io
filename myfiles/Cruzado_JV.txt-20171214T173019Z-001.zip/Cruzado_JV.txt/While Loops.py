acc = 10

while acc > 0:
    print (acc)
    acc = acc - 1
	

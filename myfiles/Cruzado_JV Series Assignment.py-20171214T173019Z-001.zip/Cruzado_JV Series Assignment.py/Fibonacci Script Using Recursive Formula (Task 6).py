def difficult():
    a = 1
    acc = 0
    for i in range (0 , n):
        print (a)
        acc = a + acc
        a = a * 3
        if i < n-1:
            print ('+')
        else:
            print ('=')
    print (acc)
    return acc
n = int(input('Please enter a number here '))
difficult()

from math import factorial


def cosine(x):
    y = 1 - (x**2)/2 + (x**4)/24 - (x**6)/720 + (x**8)/40320
    return y


pi = 3.14159265



print (cosine(0))
print (cosine (pi/2))
print (cosine (pi))

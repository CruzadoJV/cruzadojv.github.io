acc = 0


def difficult(n):
    x = n**2 + 3*n + 1
    return x


for i in range (2,6):
    print (difficult(i))
    acc = acc + difficult(i)

print(acc)

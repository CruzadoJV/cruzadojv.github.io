def imdone (n):
    acc = 1
    acc2 = 1
    print (acc)
    print (acc)
    for i in range (n - 2):
        x = acc + acc2
        acc = acc2
        acc2 = x
        print ('+')
        print (x)
    return x

imdone(200)

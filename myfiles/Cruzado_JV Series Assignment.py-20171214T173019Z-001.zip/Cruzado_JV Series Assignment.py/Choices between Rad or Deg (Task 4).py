import math

def taylor(x):
    series = 0
    for n in range (16):
        a=(((-1)**n)*(x**(2*n)))/(math.factorial(2*n))
        series= series + a
    return series

answer= input("Radians or Degrees: ")
answer.lower()
if answer in{"radians", "radian"}:
    angle_radian= float(input("Give me a radian: "))
    print ("Here is the answer: ")
    print (taylor(angle_radian))
else:
    answer in ("degrees", "degree")
    angle= float(input("What angle do you want me to calculate? : "))
    angle= angle*((math.pi)/180)
    print (angle)
    angle= (taylor(angle))
    print ("Here is the answer: ")
    print (angle)
